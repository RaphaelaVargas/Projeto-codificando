
//Animação titulo
function typeWriter(elemento) {
    const textoArray = elemento.innerHTML.split('');
    elemento.innerHTML = '';
    textoArray.forEach((letra, i) => {
        setTimeout (() => elemento.innerHTML += letra, 200 * i);
    });
}

const titulo = document.querySelector(".codifica-h1");
typeWriter(titulo);



let selecionar = document.querySelector('.select');
let chaveCifra = document.getElementById('chaveCont'); 
let seletor = document.querySelector('.selectbt'); 
let codificar = document.getElementById('codificar'); 
let decodificar = document.getElementById('decodificar');  
let botaoCod = document.getElementById('botaocodificar'); 
let texto = document.getElementById('cod-text'); 
let resultado = document.getElementById('cod-msg');  


//Animação chave
function selecao() {
    selecionar.addEventListener("click", function () {
        if (selecionar.value === "cifra") {
            chaveCifra.style.display = "block";
        } else {
            chaveCifra.style.display = "none";
        }
    });
}

//  Botão de resultado
seletor.addEventListener("click", function () {   
    if (codificar.checked) { 
        botaoCod.innerHTML = "Codificar"; 
    } else if (decodificar.checked) { 
        botaoCod.innerText = "Decodificar"; 
    }
});

// Base64 
function base64()  {  
    let texto = document.getElementById('cod-text').value;
    if (codificar.checked) {
        let encodeBase64 = btoa(texto) 
        return encodeBase64;
    } else if (decodificar.checked) {
        let decodeBase = atob(texto)   
        return decodeBase; 
    }   
}

// Cifra de César
function cifraDeCesar() {
    let texto = document.querySelector('#cod-text').value;
    let chave = parseInt(document.querySelector('#rangenumber').value);
    let saida = '';
  
    if (codificar.checked) {  
      for (let i = 0; i < texto.length; i++) {
        if (texto[i] === texto[i].toUpperCase()) {
          saida += String.fromCharCode((texto.charCodeAt(i) + chave - 65) % 26 + 65); 
        } else {
          saida += String.fromCharCode((texto.charCodeAt(i) + chave - 97) % 26 + 97);
        }
      }
      return saida;
  
    } else if (decodificar.checked) {   
      for (let i = 0; i < texto.length; i++) {
        if (texto.charCodeAt(i) >= 97 && texto.charCodeAt(i) <= 122) {
          saida += String.fromCharCode((texto.charCodeAt(i) - 97 -  chave + 26) % 26 + 97);
        } else if (texto.charCodeAt(i) >= 65 && texto.charCodeAt(i) <= 90) {
          saida += String.fromCharCode((texto.charCodeAt(i) - 65 - chave + 26) % 26 + 65);
        } else {
          saida += String.fromCharCode(texto.charCodeAt(i));
        }
      }
      return saida;
    }
  }

// Resultado
botaoCod.addEventListener("click", function (event) {  
  event.preventDefault();
  if (selecionar.value == "cifra") {  
      resultado.value = cifraDeCesar();
  } else if (selecionar.value == 'base64') { 
      resultado.value = base64(); 
  }
});
 